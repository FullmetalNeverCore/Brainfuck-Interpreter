package com.example.brainfuckj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrainfuckJApplicationTests {

	@Test
	void contextLoads() {
	}

}
