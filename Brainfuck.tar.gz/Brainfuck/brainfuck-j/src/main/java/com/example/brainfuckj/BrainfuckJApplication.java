package com.example.brainfuckj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrainfuckJApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrainfuckJApplication.class, args);
	}

}
